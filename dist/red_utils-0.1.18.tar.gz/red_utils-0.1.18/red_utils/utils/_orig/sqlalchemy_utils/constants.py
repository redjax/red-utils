## List of valid/supported databases
from __future__ import annotations

valid_db_types: list[str] = ["sqlite", "postgres", "mssql"]
