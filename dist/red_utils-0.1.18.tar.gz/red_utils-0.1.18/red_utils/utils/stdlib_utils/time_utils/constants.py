from __future__ import annotations

default_format: str = "%Y-%m-%d_%H:%M:%S"
twelve_hour_format: str = "%Y-%m-%d_%I:%M:%S%p"
