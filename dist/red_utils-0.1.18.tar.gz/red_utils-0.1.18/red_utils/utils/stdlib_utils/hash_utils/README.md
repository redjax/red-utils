# hash_utils
