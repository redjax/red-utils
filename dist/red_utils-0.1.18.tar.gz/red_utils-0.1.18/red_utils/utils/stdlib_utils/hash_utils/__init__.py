from __future__ import annotations

from .operations import get_hash_from_str

from . import operations
