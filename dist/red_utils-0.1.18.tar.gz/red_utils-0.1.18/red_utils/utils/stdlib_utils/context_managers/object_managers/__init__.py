from __future__ import annotations

from .protect import ListProtect, DictProtect

from . import protect
