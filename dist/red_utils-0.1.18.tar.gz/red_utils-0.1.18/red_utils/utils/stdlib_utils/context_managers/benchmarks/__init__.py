from __future__ import annotations

from .fn_benchmarks import async_benchmark, benchmark

from . import fn_benchmarks
