from __future__ import annotations

from .classes import UUIDLength

## Instantiated UUIDLength class
glob_uuid_lens: UUIDLength = UUIDLength()
