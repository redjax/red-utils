from __future__ import annotations

default_serialize_dir: str = ".serialize"
