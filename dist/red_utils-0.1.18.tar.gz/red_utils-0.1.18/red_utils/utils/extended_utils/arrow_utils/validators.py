## List of accepted values for 'period'
valid_time_periods: list[str] = [
    "years",
    "months",
    "weeks",
    "days",
    "hours",
    "minutes",
    "seconds",
]
