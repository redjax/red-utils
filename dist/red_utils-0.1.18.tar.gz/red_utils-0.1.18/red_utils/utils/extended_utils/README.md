# extended utils

Utilities in this directory extend 3rd party modules/libraries, such as `SQLAlchemy` or `httpx`.
