# Custom Exception Classes
