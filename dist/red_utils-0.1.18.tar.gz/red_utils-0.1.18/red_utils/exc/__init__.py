from .generic import CustomException
