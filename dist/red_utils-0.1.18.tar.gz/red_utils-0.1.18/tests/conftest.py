import pytest

pytest_plugins = ["tests.fixtures.path_fixtures"]
