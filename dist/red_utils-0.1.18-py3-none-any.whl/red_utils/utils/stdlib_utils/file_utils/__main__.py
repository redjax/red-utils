warning_msg: str = """
[WARNING]
This utility was not meant to be run directly.
You should import it:
    from red_utils.utils import file_utils
"""


if __name__ == "__main__":
    print(warning_msg)
