# stdlib utils

Utilities in this directory should *only* use `stdlib` modules, functions, and objects. If no additional libraries are installed, these utilities should continue to operate as normal.
